// 관리 페이지에서 정한 그룹 접기 단축키를 웹페이지에서 받아 백그라운드에 알린다.
// 글을 쓰는 칸이 들어 있는 프레임에서 눌러도 받도록 모든 프레임에서 돈다. 프레임마다 common.js 를 넣지 않으므로 여기서만 쓰는 값은 직접 적는다.
(() => {
  const GROUP_SHORTCUT_KEY = 'groupShortcut'; // common.js 의 같은 이름과 같아야 한다
  let shortcut = null;

  async function load() {
    try {
      const raw = (await chrome.storage.local.get(GROUP_SHORTCUT_KEY))[GROUP_SHORTCUT_KEY];
      shortcut = raw && typeof raw.code === 'string' ? raw : null;
    } catch (error) {
      console.error('[Tab Customizer] 단축키를 읽지 못했습니다.', error);
    }
  }

  window.addEventListener('keydown', event => {
    if (!shortcut || event.code !== shortcut.code || event.ctrlKey !== !!shortcut.ctrl || event.altKey !== !!shortcut.alt
      || event.shiftKey !== !!shortcut.shift || event.metaKey !== !!shortcut.meta) return;
    // 확장이 다시 로드되면 이전 스크립트는 알릴 곳이 없다
    if (!chrome.runtime?.id) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (event.repeat) return; // 누르고 있는 동안 계속 접었다 폈다 하지 않게
    chrome.runtime.sendMessage({ type: 'toggle-group' })
      .catch(error => console.error('[Tab Customizer] 그룹 접기를 요청하지 못했습니다.', error));
  }, true);

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && GROUP_SHORTCUT_KEY in changes) load();
  });
  load();
})();

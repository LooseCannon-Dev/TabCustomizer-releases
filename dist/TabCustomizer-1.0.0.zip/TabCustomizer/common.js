// 팝업·관리 페이지·콘텐츠 스크립트·백그라운드가 함께 쓰는 규칙 처리 코드.
// 꾸미기 규칙: { "naver.com": { title: "업무", emoji: "📁", enabled: true, arrange: "group", groupName: "업무", groupColor: "blue" }, ... }
//   arrange: 'group'(탭 그룹으로 묶기) 또는 'pin'(고정). 없으면 정리하지 않는다.
// 차단 목록:   { "ads.example.com": { enabled: true }, ... }
// 옴니툴 목록: 차단 목록과 같은 형식. 옴니툴에서 받아온 그대로 통째로 바꾼다(옴니툴 → 확장 한 방향).
// enabled가 없는 항목(이전 버전에서 저장)은 켜진 것으로 본다.

const STORAGE_KEY = 'rules';
const ENABLED_KEY = 'enabled'; // 꾸미기 전체 ON/OFF. 값이 없으면 켜짐
const BLOCKED_KEY = 'blocked';
const BLOCK_ENABLED_KEY = 'blockEnabled'; // 차단 전체 ON/OFF. 값이 없으면 켜짐
const OMNITOOL_KEY = 'omnitoolBlocked';
const OMNITOOL_SYNC_KEY = 'omnitoolSync'; // 옴니툴 목록 사용. 값이 없으면 꺼짐
const OMNITOOL_STATUS_KEY = 'omnitoolStatus'; // { connected, lastAttempt, lastSuccess, count, skipped, error }
const OMNITOOL_HOST = 'com.omnitool.blocklist'; // 옴니툴이 Chrome에 등록하는 연결 프로그램 이름
const OMNITOOL_MAX_ITEMS = 10000;
const MAX_TITLE_LENGTH = 200;
const MAX_GROUP_NAME_LENGTH = 50;
// Chrome 탭 그룹 색 (chrome.tabGroups.Color)
const GROUP_COLORS = [
  ['grey', '회색'], ['blue', '파랑'], ['red', '빨강'], ['yellow', '노랑'], ['green', '초록'],
  ['pink', '분홍'], ['purple', '보라'], ['cyan', '청록'], ['orange', '주황'],
];
const EMOJI_PATTERN = /\p{Extended_Pictographic}|\p{Regional_Indicator}/u;

// "https://www.naver.com/abc" 같은 입력도 "www.naver.com"으로 정리한다. 형식이 틀리면 null.
function normalizeDomain(input) {
  const text = String(input).trim().toLowerCase();
  if (!text) return null;
  let hostname;
  try {
    hostname = new URL(text.includes('://') ? text : 'http://' + text).hostname;
  } catch {
    return null;
  }
  if (!/^[a-z0-9.-]+$/.test(hostname) || hostname.startsWith('.') || hostname.endsWith('.')) return null;
  return hostname;
}

// 등록 도메인과 같거나 그 하위 도메인이면 해당된다. 구체적인(긴) 도메인부터 돌려준다.
function matchingDomains(map, hostname) {
  return Object.keys(map)
    .filter(domain => hostname === domain || hostname.endsWith('.' + domain))
    .sort((a, b) => b.length - a.length);
}

function findRule(rules, hostname) {
  for (const domain of matchingDomains(rules, hostname)) {
    const rule = sanitizeRule(rules[domain]);
    if (rule) return { domain, ...rule };
  }
  return null;
}

// 가장 구체적인 차단 항목. 그 항목이 꺼져 있으면 상위 도메인 항목이 켜져 있어도 차단하지 않는다.
function findBlocked(blocked, hostname) {
  const [domain] = matchingDomains(blocked, hostname);
  return domain ? { domain, enabled: blocked[domain]?.enabled !== false } : null;
}

function isBlockedUrl(blocked, url) {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return false;
  }
  return ['http:', 'https:'].includes(parsed.protocol) && !!findBlocked(blocked, parsed.hostname)?.enabled;
}

function graphemes(text) {
  return [...new Intl.Segmenter(undefined, { granularity: 'grapheme' }).segment(text)].map(s => s.segment);
}

// 이모지 한 개인지 검사한다. 맞으면 그 이모지, 아니면 null.
function parseEmoji(text) {
  const parts = graphemes(String(text).trim());
  if (parts.length !== 1 || !EMOJI_PATTERN.test(parts[0])) return null;
  return parts[0];
}

// 저장소·백업 파일에서 읽은 값은 형식을 다시 검사한다. 이름·아이콘·탭 정리 중 하나도 없으면 무효.
function sanitizeRule(raw) {
  if (!raw || typeof raw !== 'object') return null;
  // 브라우저는 제목의 연속 공백을 하나로 줄여 돌려주므로, 그대로 두면 다르다고 보고 계속 다시 쓰게 된다
  const title = typeof raw.title === 'string' && raw.title.length <= MAX_TITLE_LENGTH ? raw.title.replace(/[\t\n\f\r ]+/g, ' ').trim() : '';
  const emoji = typeof raw.emoji === 'string' ? parseEmoji(raw.emoji) || '' : '';
  const groupName = typeof raw.groupName === 'string' ? raw.groupName.trim().slice(0, MAX_GROUP_NAME_LENGTH) : '';
  const groupColor = GROUP_COLORS.some(([color]) => color === raw.groupColor) ? raw.groupColor : 'grey';
  const arrange = raw.arrange === 'pin' || (raw.arrange === 'group' && groupName) ? raw.arrange : '';
  if (!title && !emoji && !arrange) return null;
  const rule = { title, emoji, enabled: raw.enabled !== false };
  if (arrange) rule.arrange = arrange;
  if (arrange === 'group') Object.assign(rule, { groupName, groupColor });
  return rule;
}

async function loadMap(key) {
  const data = await chrome.storage.local.get(key);
  const map = data[key];
  if (map === undefined) return {};
  // 형식이 깨진 값을 빈 목록으로 읽으면 다음 저장 때 기존 목록이 덮여 사라지므로 여기서 멈춘다.
  if (!map || typeof map !== 'object' || Array.isArray(map)) {
    throw new Error(`저장된 ${key === BLOCKED_KEY ? '차단 목록' : '규칙'}의 형식이 올바르지 않아 읽을 수 없습니다.`);
  }
  return map;
}

// 반드시 현재 저장값을 읽은 뒤 수정해서 저장한다. 읽기에 실패하면 저장하지 않는다.
async function updateMap(key, mutate) {
  const map = await loadMap(key);
  mutate(map);
  await chrome.storage.local.set({ [key]: map });
}

async function loadSwitch(key) {
  const data = await chrome.storage.local.get(key);
  return data[key] !== false;
}

const loadRules = () => loadMap(STORAGE_KEY);
const updateRules = mutate => updateMap(STORAGE_KEY, mutate);
const loadEnabled = () => loadSwitch(ENABLED_KEY);
const loadBlocked = () => loadMap(BLOCKED_KEY);
const updateBlocked = mutate => updateMap(BLOCKED_KEY, mutate);
const loadBlockEnabled = () => loadSwitch(BLOCK_ENABLED_KEY);
const loadOmnitoolBlocked = () => loadMap(OMNITOOL_KEY);
const loadOmnitoolSync = () => chrome.storage.local.get(OMNITOOL_SYNC_KEY).then(data => data[OMNITOOL_SYNC_KEY] === true);

// 실제로 차단에 쓰는 목록. 옴니툴 목록을 쓰면 합치고, 같은 사이트는 확장에서 직접 등록한 쪽이 우선한다.
async function loadEffectiveBlocked() {
  const [own, useOmnitool] = await Promise.all([loadBlocked(), loadOmnitoolSync()]);
  return useOmnitool ? { ...(await loadOmnitoolBlocked()), ...own } : own;
}

// 옴니툴 응답 { type: 'blockList', version: 1, items: [{ domain, enabled }] }을 검사해 차단 목록 형식으로 바꾼다.
function parseOmnitoolResponse(response) {
  if (response?.type === 'error') throw new Error('옴니툴이 오류를 보냈습니다: ' + String(response.message || '').slice(0, 200));
  if (response?.type !== 'blockList' || response.version !== 1 || !Array.isArray(response.items)) {
    throw new Error('옴니툴 응답 형식이 올바르지 않습니다.');
  }
  if (response.items.length > OMNITOOL_MAX_ITEMS) throw new Error(`옴니툴 목록이 너무 깁니다(${OMNITOOL_MAX_ITEMS}개 초과).`);
  const blocked = {};
  let skipped = 0;
  for (const item of response.items) {
    const domain = typeof item?.domain === 'string' ? normalizeDomain(item.domain)?.replace(/^www\./, '') : null;
    if (!domain) {
      skipped++;
      continue;
    }
    // 같은 사이트가 여러 번 오면 하나라도 켜져 있으면 켠다
    blocked[domain] = { enabled: blocked[domain]?.enabled === true || item.enabled !== false };
  }
  return { blocked, skipped };
}

function describeNativeError(message) {
  if (/not found/i.test(message)) return '옴니툴 연결 프로그램이 등록되어 있지 않습니다. 옴니툴에서 연동을 설정해 주세요.';
  if (/forbidden/i.test(message)) return '옴니툴이 이 확장의 연결을 허용하지 않았습니다. 옴니툴의 연동 설정을 확인해 주세요.';
  return '옴니툴 연결 프로그램과의 연결이 끊겼습니다. (' + message + ')';
}

// 파일만 덮어쓰고 확장을 새로고침하지 않으면 화면은 새 버전인데 실제 동작은 이전 버전으로 남는다.
// 이때는 새 버전에서 추가한 권한이 아직 없으므로 그것으로 알아낸다.
const needsReload = () => !chrome.webNavigation || !chrome.sessions || !chrome.tabGroups || !chrome.runtime.connectNative;

// 차단 목록에 추가하면 지금 열려 있는 그 사이트 탭이 닫히므로, 추가 전에 몇 개인지 센다.
async function countOpenTabs(domain) {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  return tabs.filter(tab => isBlockedUrl({ [domain]: {} }, tab.url)).length;
}

// 탭 아이콘과 미리보기가 같은 그림을 쓰도록 이모지를 PNG로 그린다.
function emojiToDataUrl(emoji) {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d');
  ctx.font = `${size * 0.82}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(emoji, size / 2, size / 2 + size * 0.06);
  return canvas.toDataURL('image/png');
}

// 두 단계로 된 국가 도메인. 이 앞의 이름을 사이트 이름으로 쓴다.
const TWO_LEVEL_SUFFIXES = new Set([
  'co.kr', 'or.kr', 'go.kr', 'ac.kr', 'ne.kr', 're.kr', 'pe.kr', 'co.jp', 'ne.jp', 'or.jp', 'ac.jp',
  'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'com.au', 'net.au', 'org.au', 'com.cn', 'com.tw', 'com.hk',
  'com.br', 'co.in', 'co.nz', 'com.sg',
]);
const IGNORED_SUBDOMAINS = new Set(['www', 'm', 'mobile']);

// 주소로 사이트 이름을 만든다. naver.com → Naver, mail.google.com → Google Mail
function nameFromDomain(hostname) {
  if (/^[\d.]+$/.test(hostname)) return hostname;
  const labels = hostname.split('.');
  const suffixLength = labels.length > 2 && TWO_LEVEL_SUFFIXES.has(labels.slice(-2).join('.')) ? 2 : 1;
  const mainIndex = Math.max(labels.length - suffixLength - 1, 0);
  const subdomains = labels.slice(0, mainIndex).filter(label => !IGNORED_SUBDOMAINS.has(label)).reverse();
  const capitalize = word => word.charAt(0).toUpperCase() + word.slice(1);
  return [labels[mainIndex], ...subdomains].map(capitalize).join(' ');
}

// 다른 사이트 규칙에 쓰이지 않은 이모지를 자동 순서대로 고른다. 모두 쓰였으면 가장 적게 쓰인 것.
function autoEmoji(rules, currentDomain) {
  const used = new Map();
  for (const [domain, raw] of Object.entries(rules)) {
    const rule = domain === currentDomain ? null : sanitizeRule(raw);
    if (rule?.emoji) used.set(rule.emoji, (used.get(rule.emoji) || 0) + 1);
  }
  let best = AUTO_EMOJI_ORDER[0];
  for (const emoji of AUTO_EMOJI_ORDER) {
    if ((used.get(emoji) || 0) < (used.get(best) || 0)) best = emoji;
    if (!used.has(emoji)) return emoji;
  }
  return best;
}

// 페이지 안에서 탭 제목과 아이콘을 규칙대로 바꾸고, 페이지가 다시 바꾸면 덮어쓴다.
(() => {
  const OUR_ICON_ATTR = 'data-tab-customizer-icon';
  const MAX_KEPT_ICONS = 10;

  let rule = null;
  let iconUrl = null;
  let originalTitle = null;   // 덮어쓰기 직전에 페이지가 정한 제목
  let appliedTitle = null;    // 마지막으로 넣은 제목. 이것과 다르면 페이지가 제목을 바꾼 것
  let removedIcons = [];      // 규칙 해제 시 되돌릴 원래 아이콘 링크
  let observer = null;
  let observingHead = false;
  let iconVersion = 0;

  // 확장이 다시 로드되면 이전 스크립트는 저장소에 접근할 수 없으므로 스스로 멈춘다.
  function isAlive() {
    if (chrome.runtime?.id) return true;
    observer?.disconnect();
    return false;
  }

  // 원래 제목 맨 앞의 알림 개수 '(3) '는 바꾼 이름 앞에도 붙인다.
  function titleWithCount(title, original) {
    const count = /^\((\d+\+?)\)\s/.exec(original || '');
    return count ? `(${count[1]}) ${title}` : title;
  }

  function enforce() {
    if (!rule || !isAlive()) return;
    if (rule.title && (document.head || document.querySelector('title'))) {
      if (document.title !== appliedTitle) originalTitle = document.title;
      appliedTitle = titleWithCount(rule.title, originalTitle);
      if (document.title !== appliedTitle) document.title = appliedTitle;
    }
    if (iconUrl) enforceIcon();
    watch();
  }

  function enforceIcon() {
    const head = document.head;
    if (!head) return;
    for (const link of head.querySelectorAll('link[rel~="icon" i]')) {
      if (link.hasAttribute(OUR_ICON_ATTR)) continue;
      removedIcons.push(link);
      link.remove();
    }
    if (removedIcons.length > MAX_KEPT_ICONS) removedIcons = removedIcons.slice(-MAX_KEPT_ICONS);

    const ours = head.querySelector(`link[${OUR_ICON_ATTR}]`);
    if (ours && ours.getAttribute('href') === iconUrl) return;
    ours?.remove();
    const link = document.createElement('link');
    link.rel = 'icon';
    link.type = 'image/png';
    link.href = iconUrl;
    link.setAttribute(OUR_ICON_ATTR, '');
    head.appendChild(link);
  }

  // head가 생기기 전에는 문서 전체를, 생긴 뒤에는 head만 지켜본다.
  function watch() {
    if (observer && (observingHead || !document.head)) return;
    observer?.disconnect();
    observer = new MutationObserver(enforce);
    const target = document.head || document;
    observingHead = target === document.head;
    observer.observe(target, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['href', 'rel'] });
  }

  function restore() {
    observer?.disconnect();
    observer = null;
    observingHead = false;
    if (rule?.title && originalTitle !== null) document.title = originalTitle;
    const ours = document.head?.querySelector(`link[${OUR_ICON_ATTR}]`);
    if (ours) {
      ours.remove();
      // 원래 아이콘 링크가 없던 페이지는 링크를 지우기만 하면 탭에 이모지가 남으므로 기본 경로를 알려 준다
      if (!removedIcons.length) removedIcons.push(Object.assign(document.createElement('link'), { rel: 'icon', href: '/favicon.ico' }));
    }
    if (document.head) for (const link of removedIcons) document.head.appendChild(link);
    removedIcons = [];
    originalTitle = null;
    appliedTitle = null;
  }

  function setRule(next) {
    const same = rule && next && rule.title === next.title && rule.emoji === next.emoji;
    if (same || (!rule && !next)) return;
    restore();
    rule = next;
    iconUrl = next?.emoji ? emojiToDataUrl(next.emoji) : null;
    enforce();
  }

  // 페이지를 여는 도중에 넣은 아이콘을 Chrome이 반영하지 않는 경우가 있어, 로딩이 끝난 뒤 새 링크로 한 번 더 넣는다.
  // 주소가 같으면 Chrome이 변경으로 보지 않으므로 끝에 번호(#n)를 붙인다. 그림은 그때 다시 그린다.
  function reinsertIcon() {
    if (!rule?.emoji || !isAlive()) return;
    iconUrl = `${emojiToDataUrl(rule.emoji)}#${++iconVersion}`;
    enforce();
  }

  async function refresh() {
    if (!isAlive()) return;
    try {
      const [rules, enabled] = await Promise.all([loadRules(), loadEnabled()]);
      const found = enabled ? findRule(rules, location.hostname) : null;
      setRule(found?.enabled ? found : null);
    } catch (error) {
      console.error('[Tab Customizer] 규칙을 읽지 못했습니다.', error);
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && (STORAGE_KEY in changes || ENABLED_KEY in changes)) refresh();
  });
  window.addEventListener('load', () => setTimeout(reinsertIcon, 300));
  window.addEventListener('pageshow', event => { if (event.persisted) reinsertIcon(); });
  refresh();
})();

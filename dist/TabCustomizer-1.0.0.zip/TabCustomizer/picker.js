// 분류별 이모지 선택 목록. 이모지를 누르면 onSelect(이모지)를 부른다.
function createEmojiPicker(onSelect) {
  const root = document.createElement('div');
  root.className = 'picker';
  const tabs = document.createElement('div');
  tabs.className = 'picker-tabs';
  const grid = document.createElement('div');
  grid.className = 'picker-grid';

  function show(index) {
    [...tabs.children].forEach((tab, i) => tab.classList.toggle('active', i === index));
    grid.replaceChildren(...EMOJI_CATEGORIES[index].emojis.map(emoji => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'emoji-option';
      button.textContent = emoji;
      button.title = emoji;
      button.addEventListener('click', () => onSelect(emoji));
      return button;
    }));
  }

  EMOJI_CATEGORIES.forEach((category, index) => {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.textContent = category.name;
    tab.addEventListener('click', () => show(index));
    tabs.appendChild(tab);
  });
  show(0);
  root.append(tabs, grid);
  return root;
}

document.getElementById('version').textContent = 'v' + chrome.runtime.getManifest().version;
const rowsBody = document.getElementById('rows');
const rowTemplate = document.getElementById('row-template');
const pickerTemplate = document.getElementById('picker-template');
const message = document.getElementById('message');

let openPicker = null; // 열려 있는 아이콘 선택 줄

// 머리글의 상태 표시(켜짐·꺼짐 등)
function setBadge(id, text, tone) {
  const badge = document.getElementById(id);
  badge.textContent = text;
  badge.className = `badge badge-${tone}`;
}

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle('error', isError);
}

function closePicker() {
  openPicker?.remove();
  openPicker = null;
}

async function saveRow(domain, title, icon, arrangement) {
  if (!arrangement) return showMessage(`${domain}: 그룹 이름을 입력해 주세요.`, true);
  if (!title && !icon.emoji && !icon.iconId && !arrangement.arrange) return showMessage(`${domain}: 탭 이름, 아이콘, 탭 정리 중 하나는 정해 주세요.`, true);
  try {
    await updateRules(rules => {
      rules[domain] = { title, ...icon, enabled: rules[domain]?.enabled !== false, ...arrangement };
    });
    showMessage(`${domain} 규칙을 저장했습니다.`);
  } catch (error) {
    showMessage('저장하지 못했습니다: ' + error.message, true);
  }
}

async function setRowEnabled(domain, checkbox) {
  const enabled = checkbox.checked;
  try {
    await updateRules(rules => {
      if (!rules[domain]) throw new Error('규칙이 삭제되어 있습니다.');
      rules[domain].enabled = enabled;
    });
    showMessage(`${domain}: ${enabled ? '켰습니다.' : '껐습니다. 규칙은 남아 있습니다.'}`);
  } catch (error) {
    checkbox.checked = !enabled;
    showMessage('바꾸지 못했습니다: ' + error.message, true);
  }
}

async function removeRow(domain) {
  if (!confirm(`${domain} 규칙을 삭제할까요?`)) return;
  try {
    await updateRules(rules => { delete rules[domain]; });
    showMessage(`${domain} 규칙을 삭제했습니다.`);
  } catch (error) {
    showMessage('삭제하지 못했습니다: ' + error.message, true);
  }
}

function buildRow(domain, rule, rules, groups, icons) {
  const row = rowTemplate.content.firstElementChild.cloneNode(true);
  const arrangeControls = createArrangeControls(groups);
  arrangeControls.set(rule);
  row.querySelector('.arrange-cell').appendChild(arrangeControls.element);
  const titleInput = row.querySelector('.title');
  const iconButton = row.querySelector('.icon-button');
  const preview = row.querySelector('.icon-preview');
  const iconNone = row.querySelector('.icon-none');
  const enabledBox = row.querySelector('.enabled');
  let icon;

  // 지워진 그림을 가리키면 원래 아이콘으로 본다
  const setIcon = choice => {
    icon = choice.iconId && !icons[choice.iconId] ? { emoji: '' } : choice;
    const url = iconUrlFor(icon, icons);
    preview.hidden = !url;
    iconNone.hidden = !!url;
    if (url) preview.src = url;
  };
  setIcon(iconChoice(rule));

  row.classList.toggle('disabled', !rule.enabled);
  row.querySelector('.domain').textContent = domain;
  titleInput.value = rule.title;
  enabledBox.checked = rule.enabled;

  iconButton.addEventListener('click', () => {
    const wasOpen = openPicker?.previousElementSibling === row;
    closePicker();
    if (wasOpen) return;
    openPicker = pickerTemplate.content.firstElementChild.cloneNode(true);
    openPicker.querySelector('td').appendChild(createEmojiPicker(setIcon, icons, "아래 '내 아이콘'에서 그림을 올리면 여기서 고를 수 있습니다."));
    openPicker.querySelector('.auto-emoji').addEventListener('click', () => setIcon({ emoji: autoEmoji(rules, domain) }));
    openPicker.querySelector('.clear-emoji').addEventListener('click', () => setIcon({ emoji: '' }));
    openPicker.querySelector('.close-picker').addEventListener('click', closePicker);
    row.after(openPicker);
  });
  row.querySelector('.auto-title').addEventListener('click', () => { titleInput.value = nameFromDomain(domain); });
  enabledBox.addEventListener('change', () => setRowEnabled(domain, enabledBox));
  row.querySelector('.save').addEventListener('click', () => saveRow(domain, titleInput.value.trim(), icon, arrangeControls.get()));
  row.querySelector('.remove').addEventListener('click', () => removeRow(domain));
  return row;
}

async function render() {
  let rules, icons;
  try {
    [rules, icons] = await Promise.all([loadRules(), loadIcons()]);
    const enabled = await loadEnabled();
    document.getElementById('global-off').hidden = enabled;
    setBadge('badge-customize', enabled ? '꾸미기 켜짐' : '꾸미기 꺼짐', enabled ? 'on' : 'off');
  } catch (error) {
    return showMessage(error.message, true);
  }

  closePicker();
  const domains = Object.keys(rules).sort();
  const groups = groupsFromRules(rules);
  rowsBody.replaceChildren(...domains.map(domain =>
    buildRow(domain, sanitizeRule(rules[domain]) || { title: '', emoji: '', enabled: true }, rules, groups, icons)));
  document.getElementById('table').hidden = domains.length === 0;
  document.getElementById('rules-count').textContent = domains.length;
  document.getElementById('empty').hidden = domains.length > 0;
}

const iconsChanged = changes => Object.keys(changes).some(key => key.startsWith(ICON_PREFIX));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && (STORAGE_KEY in changes || ENABLED_KEY in changes || iconsChanged(changes))) render();
});
render();

// ── 내 아이콘 ──
const ICON_SIZE = 64;
const MAX_ICON_FILE_BYTES = 20 * 1024 * 1024;
const iconTemplate = document.getElementById('icon-item-template');
const iconMessage = document.getElementById('icon-message');

function showIconMessage(text, isError = false) {
  iconMessage.textContent = text;
  iconMessage.classList.toggle('error', isError);
}

// 그림을 탭 아이콘 크기의 정사각형 PNG로 줄인다. 비율은 그대로 두고 남는 곳은 투명하게 둔다.
async function imageToIconData(file) {
  const url = URL.createObjectURL(file);
  try {
    const image = new Image();
    image.src = url;
    await image.decode();
    // 크기가 적혀 있지 않은 SVG는 0으로 읽힌다
    let width = image.naturalWidth || ICON_SIZE;
    let height = image.naturalHeight || ICON_SIZE;
    let source = image;
    // 한 번에 크게 줄이면 거칠어지므로 반씩 줄여 간다
    while (Math.max(width, height) > ICON_SIZE * 2) {
      width = Math.ceil(width / 2);
      height = Math.ceil(height / 2);
      const step = Object.assign(document.createElement('canvas'), { width, height });
      const stepContext = step.getContext('2d');
      stepContext.imageSmoothingQuality = 'high';
      stepContext.drawImage(source, 0, 0, width, height);
      source = step;
    }
    const scale = ICON_SIZE / Math.max(width, height);
    const canvas = Object.assign(document.createElement('canvas'), { width: ICON_SIZE, height: ICON_SIZE });
    const context = canvas.getContext('2d');
    context.imageSmoothingQuality = 'high';
    context.drawImage(source, (ICON_SIZE - width * scale) / 2, (ICON_SIZE - height * scale) / 2, width * scale, height * scale);
    return canvas.toDataURL('image/png');
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function uploadIcon(file) {
  if (file.size > MAX_ICON_FILE_BYTES) return showIconMessage(`'${file.name}'은(는) 너무 큽니다(20MB 초과).`, true);
  let data;
  try {
    data = await imageToIconData(file);
  } catch (error) {
    return showIconMessage(`'${file.name}'을(를) 그림으로 읽지 못했습니다. PNG·JPG·GIF·WebP·SVG·ICO 파일을 올려 주세요. (${error.message})`, true);
  }
  if (data.length > MAX_ICON_DATA_LENGTH) return showIconMessage(`'${file.name}'은(는) 줄여도 저장하기에 너무 큽니다.`, true);
  try {
    if (Object.keys(await loadIcons()).length >= MAX_ICONS) {
      return showIconMessage(`그림은 ${MAX_ICONS}개까지 올릴 수 있습니다. 쓰지 않는 그림을 지운 뒤 올려 주세요.`, true);
    }
    await chrome.storage.local.set({ [ICON_PREFIX + crypto.randomUUID()]: { name: file.name.slice(0, 100), data, added: Date.now() } });
  } catch (error) {
    return showIconMessage('저장하지 못했습니다: ' + error.message, true);
  }
  showIconMessage(`'${file.name}'을(를) 올렸습니다. 규칙의 아이콘을 눌러 '내 아이콘'에서 고를 수 있습니다.`);
}

// 쓰고 있는 그림을 지우면 그 사이트 규칙이 비어 버릴 수 있으므로, 쓰는 사이트가 있으면 지우지 않는다.
async function removeIcon(id, name) {
  let rules;
  try {
    rules = await loadRules();
  } catch (error) {
    return showIconMessage('삭제하지 못했습니다: ' + error.message, true);
  }
  const users = Object.keys(rules).filter(domain => sanitizeRule(rules[domain])?.iconId === id);
  if (users.length) return showIconMessage(`이 그림을 쓰는 사이트가 있어 삭제할 수 없습니다: ${users.join(', ')}. 그 사이트의 아이콘을 먼저 바꿔 주세요.`, true);
  if (!confirm(`'${name || '이름 없는 그림'}'을(를) 삭제할까요?`)) return;
  try {
    await chrome.storage.local.remove(ICON_PREFIX + id);
  } catch (error) {
    return showIconMessage('삭제하지 못했습니다: ' + error.message, true);
  }
  showIconMessage('삭제했습니다.');
}

async function renderIcons() {
  let icons;
  try {
    icons = sortedIcons(await loadIcons());
  } catch (error) {
    return showIconMessage('올린 그림을 읽지 못했습니다: ' + error.message, true);
  }
  document.getElementById('icon-list').replaceChildren(...icons.map(icon => {
    const item = iconTemplate.content.firstElementChild.cloneNode(true);
    item.title = icon.name;
    item.querySelector('.icon-large').src = icon.data;
    item.querySelector('.icon-name').textContent = icon.name;
    item.querySelector('.remove').addEventListener('click', () => removeIcon(icon.id, icon.name));
    return item;
  }));
  document.getElementById('icons-count').textContent = icons.length;
  document.getElementById('icons-empty').hidden = icons.length > 0;
}

const iconFile = document.getElementById('icon-file');
document.getElementById('icon-upload').addEventListener('click', () => iconFile.click());
iconFile.addEventListener('change', () => {
  if (iconFile.files[0]) uploadIcon(iconFile.files[0]);
  iconFile.value = '';
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && iconsChanged(changes)) renderIcons();
});
renderIcons();

// ── 차단할 사이트 ──
const blockRows = document.getElementById('block-rows');
const blockTemplate = document.getElementById('block-row-template');
const closedRows = document.getElementById('closed-rows');
const closedTemplate = document.getElementById('closed-row-template');
const blockMessage = document.getElementById('block-message');

function showBlockMessage(text, isError = false) {
  blockMessage.textContent = text;
  blockMessage.classList.toggle('error', isError);
}

// 추가하면 열려 있는 그 사이트 탭이 닫히므로 개수를 알리고 확인받는다.
async function addBlocked(input) {
  // 팝업의 '이 사이트 차단'과 같게 www.는 떼어 m.·news. 같은 다른 하위 주소도 함께 막는다
  const domain = normalizeDomain(input)?.replace(/^www\./, '');
  if (!domain) return showBlockMessage('사이트 주소 형식이 올바르지 않습니다.', true);
  try {
    const [blocked, enabled] = await Promise.all([loadBlocked(), loadBlockEnabled()]);
    if (blocked[domain] && blocked[domain].enabled !== false) return showBlockMessage(`${domain}은(는) 이미 차단 목록에 있습니다.`, true);
    const count = enabled ? await countOpenTabs(domain) : 0;
    if (count && !confirm(`${domain}을(를) 차단할까요? 하위 주소도 함께 차단됩니다.\n지금 열려 있는 이 사이트 탭 ${count}개가 닫힙니다.`)) return;
    await updateBlocked(map => { map[domain] = { enabled: true }; });
    showBlockMessage(`${domain}을(를) 차단 목록에 추가했습니다.`);
    return true;
  } catch (error) {
    showBlockMessage('추가하지 못했습니다: ' + error.message, true);
  }
}

async function setBlockedEnabled(domain, checkbox) {
  const enabled = checkbox.checked;
  try {
    const count = enabled && await loadBlockEnabled() ? await countOpenTabs(domain) : 0;
    if (count && !confirm(`${domain} 차단을 켜면 지금 열려 있는 이 사이트 탭 ${count}개가 닫힙니다. 켤까요?`)) {
      checkbox.checked = false;
      return;
    }
    await updateBlocked(map => {
      if (!map[domain]) throw new Error('차단 목록에서 삭제되어 있습니다.');
      map[domain].enabled = enabled;
    });
    showBlockMessage(`${domain}: ${enabled ? '차단을 켰습니다.' : '차단을 껐습니다. 목록에는 남아 있습니다.'}`);
  } catch (error) {
    checkbox.checked = !enabled;
    showBlockMessage('바꾸지 못했습니다: ' + error.message, true);
  }
}

async function removeBlocked(domain) {
  if (!confirm(`${domain}을(를) 차단 목록에서 삭제할까요?`)) return;
  try {
    await updateBlocked(map => { delete map[domain]; });
    showBlockMessage(`${domain}을(를) 차단 목록에서 삭제했습니다.`);
  } catch (error) {
    showBlockMessage('삭제하지 못했습니다: ' + error.message, true);
  }
}

function formatTime(seconds) {
  const date = new Date(seconds * 1000);
  const sameDay = date.toDateString() === new Date().toDateString();
  return sameDay ? date.toLocaleTimeString('ko-KR', { hour: '2-digit', minute: '2-digit' }) : date.toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

// 최근 닫힌 탭(창째 닫힌 경우 그 안의 탭 포함)을 사이트별로 하나씩, 최근 것부터 보여 준다.
async function renderClosed(blocked) {
  const sessions = await chrome.sessions.getRecentlyClosed({ maxResults: chrome.sessions.MAX_SESSION_RESULTS });
  const seen = new Set();
  const items = [];
  for (const session of sessions) {
    for (const tab of session.tab ? [session.tab] : session.window?.tabs || []) {
      let url;
      try {
        url = new URL(tab.url);
      } catch {
        continue;
      }
      if (!['http:', 'https:'].includes(url.protocol)) continue;
      const domain = url.hostname.replace(/^www\./, '');
      if (seen.has(domain) || findBlocked(blocked, url.hostname)) continue;
      seen.add(domain);
      items.push({ domain, title: tab.title || '', time: session.lastModified });
    }
  }
  closedRows.replaceChildren(...items.map(item => {
    const row = closedTemplate.content.firstElementChild.cloneNode(true);
    row.querySelector('.domain').textContent = item.domain;
    row.querySelector('.closed-title').textContent = item.title;
    row.querySelector('.nowrap').textContent = formatTime(item.time);
    row.querySelector('.block').addEventListener('click', () => addBlocked(item.domain));
    return row;
  }));
  document.getElementById('closed-table').hidden = items.length === 0;
  document.getElementById('closed-empty').hidden = items.length > 0;
}

async function renderBlocked() {
  let blocked;
  try {
    blocked = await loadBlocked();
    const blockEnabled = await loadBlockEnabled();
    document.getElementById('block-off').hidden = blockEnabled;
    setBadge('badge-block', blockEnabled ? '차단 켜짐' : '차단 꺼짐', blockEnabled ? 'on' : 'off');
  } catch (error) {
    return showBlockMessage(error.message, true);
  }
  const domains = Object.keys(blocked).sort();
  blockRows.replaceChildren(...domains.map(domain => {
    const row = blockTemplate.content.firstElementChild.cloneNode(true);
    const enabledBox = row.querySelector('.enabled');
    const enabled = blocked[domain]?.enabled !== false;
    row.classList.toggle('disabled', !enabled);
    row.querySelector('.domain').textContent = domain;
    enabledBox.checked = enabled;
    enabledBox.addEventListener('change', () => setBlockedEnabled(domain, enabledBox));
    row.querySelector('.remove').addEventListener('click', () => removeBlocked(domain));
    return row;
  }));
  document.getElementById('block-table').hidden = domains.length === 0;
  document.getElementById('block-count').textContent = domains.length;
  document.getElementById('block-empty').hidden = domains.length > 0;
  await renderOmnitool();
  if (!needsReload()) await renderClosed(await loadEffectiveBlocked()).catch(error => showBlockMessage('최근 닫힌 탭을 읽지 못했습니다: ' + error.message, true));
}

document.getElementById('block-form').addEventListener('submit', async event => {
  event.preventDefault();
  const input = document.getElementById('block-input');
  if (await addBlocked(input.value)) input.value = '';
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if ([BLOCKED_KEY, BLOCK_ENABLED_KEY, OMNITOOL_KEY, OMNITOOL_SYNC_KEY, OMNITOOL_STATUS_KEY].some(key => key in changes)) renderBlocked();
});
chrome.sessions?.onChanged.addListener(() => renderBlocked());
document.getElementById('reload-needed').hidden = !needsReload();
renderBlocked();

// ── 옴니툴 차단 목록 ──
const omniToggle = document.getElementById('omni-toggle');
const omniStatus = document.getElementById('omni-status');

function formatDateTime(iso) {
  return new Date(iso).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

async function renderOmnitool() {
  let enabled, blocked, status;
  try {
    [enabled, blocked, status] = await Promise.all([
      loadOmnitoolSync(),
      loadOmnitoolBlocked(),
      chrome.storage.local.get(OMNITOOL_STATUS_KEY).then(data => data[OMNITOOL_STATUS_KEY] || {}),
    ]);
  } catch (error) {
    omniStatus.textContent = error.message;
    return;
  }
  omniToggle.checked = enabled;
  document.getElementById('omni-sync').disabled = !enabled || needsReload();

  const lines = [];
  if (!enabled) lines.push('꺼져 있습니다. 켜면 옴니툴 목록을 받아오는 즉시 열려 있는 해당 사이트 탭이 닫힙니다.');
  else if (status.connected && !status.error) lines.push('옴니툴과 연결되어 있습니다. 옴니툴에서 목록을 바꾸면 바로 반영됩니다.');
  if (status.lastSuccess) {
    lines.push(`마지막으로 받아온 시각: ${formatDateTime(status.lastSuccess)} · ${status.count}개` + (status.skipped ? ` (형식이 맞지 않아 뺀 항목 ${status.skipped}개)` : ''));
  }
  if (status.error) {
    lines.push(`${formatDateTime(status.lastAttempt)}에 받아오지 못했습니다: ${status.error}` + (status.lastSuccess ? ' 마지막으로 받은 목록으로 계속 차단합니다.' : ''));
  }
  omniStatus.innerText = lines.join('\n');
  omniStatus.classList.toggle('error', enabled && !!status.error);
  if (!enabled) setBadge('omni-badge', '사용 안 함', 'off');
  else if (status.error) setBadge('omni-badge', status.connected ? '오류' : '연결 안 됨', 'error');
  else setBadge('omni-badge', status.connected ? '연결됨' : '연결 중', status.connected ? 'on' : 'off');

  const domains = enabled ? Object.keys(blocked).sort() : [];
  document.getElementById('omni-rows').replaceChildren(...domains.map(domain => {
    const row = document.createElement('tr');
    const on = blocked[domain]?.enabled !== false;
    row.classList.toggle('disabled', !on);
    row.append(Object.assign(document.createElement('td'), { className: 'domain', textContent: domain }),
      Object.assign(document.createElement('td'), { className: 'muted', textContent: on ? '차단' : '꺼짐' }));
    return row;
  }));
  document.getElementById('omni-table').hidden = domains.length === 0;
}

omniToggle.addEventListener('change', async () => {
  try {
    await chrome.storage.local.set({ [OMNITOOL_SYNC_KEY]: omniToggle.checked });
  } catch (error) {
    omniToggle.checked = !omniToggle.checked;
    showBlockMessage('바꾸지 못했습니다: ' + error.message, true);
  }
});
document.getElementById('omni-sync').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'omnitool-refresh' })
    .catch(error => showBlockMessage('받아오기를 요청하지 못했습니다: ' + error.message, true));
});

// ── 백업·복원 ──
const BACKUP_APP = 'TabCustomizer';
const BACKUP_FORMAT = 1;
const MAX_BACKUP_BYTES = 5 * 1024 * 1024; // 올린 그림을 최대로 담아도 들어가는 크기
const backupMessage = document.getElementById('backup-message');
const importPanel = document.getElementById('import-panel');
let pendingImport = null; // 검사를 마친 불러올 내용

function showBackupMessage(text, isError = false) {
  backupMessage.textContent = text;
  backupMessage.classList.toggle('error', isError);
}

function backupFileName() {
  const now = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `TabCustomizer-backup-${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}.json`;
}

async function exportBackup() {
  let data;
  try {
    const [rules, enabled, blocked, blockEnabled, icons] = await Promise.all([loadRules(), loadEnabled(), loadBlocked(), loadBlockEnabled(), loadIcons()]);
    data = { app: BACKUP_APP, format: BACKUP_FORMAT, exportedAt: new Date().toISOString(), rules, enabled, blocked, blockEnabled, icons };
  } catch (error) {
    return showBackupMessage('백업하지 못했습니다: ' + error.message, true);
  }
  const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' }));
  const link = Object.assign(document.createElement('a'), { href: url, download: backupFileName() });
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
  showBackupMessage(`규칙 ${Object.keys(data.rules).length}개, 그림 ${Object.keys(data.icons).length}개, 차단 ${Object.keys(data.blocked).length}개를 '${link.download}' 파일로 저장했습니다. (다운로드 폴더)`);
}

// 파일 내용을 검사해 쓸 수 있는 항목만 남긴다. 버린 항목 수도 함께 돌려준다.
function parseBackup(text) {
  let data;
  try {
    data = JSON.parse(text);
  } catch {
    throw new Error('JSON 형식이 아닙니다.');
  }
  if (!data || data.app !== BACKUP_APP || data.format !== BACKUP_FORMAT) throw new Error('Tab Customizer 백업 파일이 아닙니다.');
  const isMap = value => value && typeof value === 'object' && !Array.isArray(value);
  const rules = {};
  const blocked = {};
  const icons = {};
  let skipped = 0;
  for (const [domain, raw] of Object.entries(isMap(data.rules) ? data.rules : {})) {
    const key = normalizeDomain(domain);
    const rule = sanitizeRule(raw);
    if (key && rule) rules[key] = rule;
    else skipped++;
  }
  for (const [domain, raw] of Object.entries(isMap(data.blocked) ? data.blocked : {})) {
    const key = normalizeDomain(domain);
    if (key && isMap(raw)) blocked[key] = { enabled: raw.enabled !== false };
    else skipped++;
  }
  // 그림이 없는 이전 백업 파일도 그대로 읽는다
  for (const [id, raw] of Object.entries(isMap(data.icons) ? data.icons : {})) {
    const icon = ICON_ID_PATTERN.test(id) ? sanitizeIcon(raw) : null;
    if (icon) icons[id] = icon;
    else skipped++;
  }
  if (Object.keys(icons).length > MAX_ICONS) throw new Error(`그림이 ${MAX_ICONS}개를 넘습니다.`);
  return {
    rules,
    blocked,
    icons,
    skipped,
    enabled: typeof data.enabled === 'boolean' ? data.enabled : true,
    blockEnabled: typeof data.blockEnabled === 'boolean' ? data.blockEnabled : true,
  };
}

async function openImport(file) {
  importPanel.hidden = true;
  pendingImport = null;
  if (file.size > MAX_BACKUP_BYTES) return showBackupMessage(`파일이 너무 큽니다(${MAX_BACKUP_BYTES / 1024 / 1024}MB 초과). 백업 파일이 맞는지 확인해 주세요.`, true);
  let backup;
  try {
    backup = parseBackup(await file.text());
  } catch (error) {
    return showBackupMessage(`'${file.name}'을(를) 불러오지 못했습니다: ${error.message}`, true);
  }
  let current = null;
  try {
    const [rules, blocked, icons] = await Promise.all([loadRules(), loadBlocked(), loadIcons()]);
    current = { rules, blocked, icons };
  } catch {
    // 지금 설정이 깨져 있으면 합치기는 할 수 없고 전부 바꾸기만 할 수 있다
  }
  const ruleCount = Object.keys(backup.rules).length;
  const blockCount = Object.keys(backup.blocked).length;
  const iconCount = Object.keys(backup.icons).length;
  const lines = [`'${file.name}': 꾸미기 규칙 ${ruleCount}개, 그림 ${iconCount}개, 차단 ${blockCount}개` + (backup.skipped ? ` (형식이 맞지 않아 뺀 항목 ${backup.skipped}개)` : '')];
  if (current) {
    const overlap = Object.keys(backup.rules).filter(d => d in current.rules).length + Object.keys(backup.blocked).filter(d => d in current.blocked).length;
    lines.push(`· 합치기: 지금 설정은 남기고 더합니다. 같은 사이트 ${overlap}개는 파일 내용으로 바뀝니다. 스위치 상태는 그대로 둡니다.`);
    lines.push(`· 전부 바꾸기: 지금 규칙 ${Object.keys(current.rules).length}개, 그림 ${Object.keys(current.icons).length}개, 차단 ${Object.keys(current.blocked).length}개를 지우고 파일 내용과 스위치 상태로 바꿉니다.`);
  } else {
    lines.push('· 지금 저장된 설정을 읽을 수 없어 합치기는 할 수 없습니다. 전부 바꾸기만 할 수 있습니다.');
  }
  document.getElementById('import-summary').innerText = lines.join('\n');
  document.getElementById('import-merge').disabled = !current;
  pendingImport = { backup, current, fileName: file.name };
  importPanel.hidden = false;
  showBackupMessage('');
}

// 차단 목록이 바뀌면 열려 있는 차단 사이트 탭이 닫히므로 미리 개수를 알린다.
async function closingNotice(blocked, blockEnabled) {
  if (!blockEnabled) return '';
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  const count = tabs.filter(tab => isBlockedUrl(blocked, tab.url)).length;
  return count ? `\n지금 열려 있는 차단 사이트 탭 ${count}개가 닫힙니다.` : '';
}

async function applyImport(mode) {
  if (!pendingImport) return;
  const { backup, current } = pendingImport;
  let next, existingIcons;
  try {
    // 불러오기 창을 연 뒤에 바뀐 설정도 지우지 않도록 적용 직전에 다시 읽는다
    existingIcons = await loadIcons();
  } catch (error) {
    return showBackupMessage('불러오지 못했습니다: ' + error.message, true);
  }
  const iconEntries = Object.fromEntries(Object.entries(backup.icons).map(([id, icon]) => [ICON_PREFIX + id, icon]));
  let iconCount = Object.keys(backup.icons).length;
  let staleIcons = []; // 전부 바꾸기에서 지울 지금 그림
  if (mode === 'merge') {
    let latest;
    try {
      const [rules, blocked] = await Promise.all([loadRules(), loadBlocked()]);
      latest = { rules, blocked };
    } catch (error) {
      return showBackupMessage('합치지 못했습니다: ' + error.message, true);
    }
    iconCount = new Set([...Object.keys(existingIcons), ...Object.keys(backup.icons)]).size;
    if (iconCount > MAX_ICONS) return showBackupMessage(`합치면 그림이 ${iconCount}개가 되어 ${MAX_ICONS}개를 넘습니다. 쓰지 않는 그림을 지운 뒤 다시 합쳐 주세요.`, true);
    next = { [STORAGE_KEY]: { ...latest.rules, ...backup.rules }, [BLOCKED_KEY]: { ...latest.blocked, ...backup.blocked }, ...iconEntries };
    const notice = await closingNotice(next[BLOCKED_KEY], await loadBlockEnabled());
    if (notice && !confirm(`합치기를 진행할까요?${notice}`)) return;
  } else {
    next = { [STORAGE_KEY]: backup.rules, [BLOCKED_KEY]: backup.blocked, [ENABLED_KEY]: backup.enabled, [BLOCK_ENABLED_KEY]: backup.blockEnabled, ...iconEntries };
    staleIcons = Object.keys(existingIcons).filter(id => !(id in backup.icons)).map(id => ICON_PREFIX + id);
    const removing = current ? `지금 규칙 ${Object.keys(current.rules).length}개, 그림 ${Object.keys(existingIcons).length}개, 차단 ${Object.keys(current.blocked).length}개가 지워집니다.` : '지금 저장된 설정이 지워집니다.';
    if (!confirm(`전부 바꿀까요? ${removing}${await closingNotice(backup.blocked, backup.blockEnabled)}`)) return;
  }
  try {
    await chrome.storage.local.set(next);
  } catch (error) {
    return showBackupMessage('불러오지 못했습니다: ' + error.message, true);
  }
  importPanel.hidden = true;
  pendingImport = null;
  const done = `${mode === 'merge' ? '합쳤습니다' : '바꿨습니다'}. 꾸미기 규칙 ${Object.keys(next[STORAGE_KEY]).length}개, 그림 ${iconCount}개, 차단 ${Object.keys(next[BLOCKED_KEY]).length}개입니다.`;
  try {
    await chrome.storage.local.remove(staleIcons);
  } catch (error) {
    return showBackupMessage(`${done} 다만 이전 그림 ${staleIcons.length}개를 지우지 못해 목록에 남아 있습니다: ${error.message}`, true);
  }
  showBackupMessage(done);
}

const importFile = document.getElementById('import-file');
document.getElementById('export').addEventListener('click', exportBackup);
document.getElementById('import').addEventListener('click', () => importFile.click());
importFile.addEventListener('change', () => {
  if (importFile.files[0]) openImport(importFile.files[0]);
  importFile.value = '';
});
document.getElementById('import-merge').addEventListener('click', () => applyImport('merge'));
document.getElementById('import-replace').addEventListener('click', () => applyImport('replace'));
document.getElementById('import-cancel').addEventListener('click', () => {
  importPanel.hidden = true;
  pendingImport = null;
});

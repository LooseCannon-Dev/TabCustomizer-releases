importScripts('common.js');

// 설치·업데이트 직후에는 이미 열려 있던 탭에 콘텐츠 스크립트가 없으므로 직접 넣어 준다.
chrome.runtime.onInstalled.addListener(async () => {
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    if (tab.discarded) continue; // 잠든 탭은 다시 열릴 때 자동으로 스크립트가 들어간다
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['common.js', 'content.js'] });
    } catch (error) {
      console.warn(`[Tab Customizer] 탭 ${tab.id}에 스크립트를 넣지 못했습니다.`, error);
    }
  }
});

// ── 사이트 차단 ──
// 차단 사이트가 새 탭(이전에 본 페이지가 없는 탭)으로 열리면 탭을 닫고,
// 보던 탭이 차단 사이트로 넘어가면 이전 페이지로 되돌린다.

const GOOD_URLS_KEY = 'goodUrls';
const goodUrls = new Map(); // 탭 id → 그 탭에서 마지막으로 본 차단되지 않은 주소
const recentlyHandled = new Map(); // 탭 id → { url, time } 마지막으로 처리한 차단 이동
let blockState = null; // { enabled, blocked } 저장값 캐시

async function getBlockState() {
  if (!blockState) {
    const [enabled, blocked] = await Promise.all([loadBlockEnabled(), loadEffectiveBlocked()]);
    blockState = { enabled, blocked };
  }
  return blockState;
}

function isBlocked(state, url) {
  return state.enabled && isBlockedUrl(state.blocked, url);
}

// 서비스 워커는 수시로 내려가므로 탭별 기록을 세션 저장소에 둔다. 처음에는 열린 탭의 현재 주소로 채운다.
const ready = (async () => {
  const data = await chrome.storage.session.get(GOOD_URLS_KEY);
  for (const [tabId, url] of Object.entries(data[GOOD_URLS_KEY] || {})) goodUrls.set(Number(tabId), url);
  const state = await getBlockState().catch(() => ({ enabled: false, blocked: {} }));
  for (const tab of await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })) {
    if (!goodUrls.has(tab.id) && !isBlocked(state, tab.url)) goodUrls.set(tab.id, tab.url);
  }
  saveGoodUrls();
})();

function saveGoodUrls() {
  chrome.storage.session.set({ [GOOD_URLS_KEY]: Object.fromEntries(goodUrls) })
    .catch(error => console.error('[Tab Customizer] 탭 기록을 저장하지 못했습니다.', error));
}

// 마지막 남은 일반 탭을 닫으면 Chrome이 종료되므로, 그때는 새 탭 화면으로 바꾼다.
async function closeTab(tabId) {
  const normalTabs = await chrome.tabs.query({ windowType: 'normal' });
  if (normalTabs.length === 1 && normalTabs[0].id === tabId) {
    await chrome.tabs.update(tabId, { url: 'chrome://newtab/' });
  } else {
    await chrome.tabs.remove(tabId);
  }
}

async function goBackOrClose(tabId) {
  try {
    await chrome.tabs.goBack(tabId);
  } catch {
    // 뒤로 갈 기록이 없으면(이전 주소가 바꿔치기된 경우 등) 닫는다
    await closeTab(tabId);
  }
}

// committed: 탭이 실제로 그 주소로 넘어갔는지(false면 이동을 막 시작한 시점)
async function handleNavigation(tabId, url, committed) {
  if (tabId < 0) return;
  await ready;
  let state;
  try {
    state = await getBlockState();
  } catch (error) {
    return console.error('[Tab Customizer] 차단 목록을 읽지 못했습니다.', error);
  }

  if (!isBlocked(state, url)) {
    if (committed && /^https?:/.test(url)) {
      goodUrls.set(tabId, url);
      saveGoodUrls();
    }
    return;
  }

  const last = recentlyHandled.get(tabId);
  const sinceLast = last ? Date.now() - last.time : Infinity;
  if (last?.url === url && sinceLast < 1000) return; // 같은 이동이 여러 이벤트로 들어온 경우

  try {
    if (!goodUrls.has(tabId) || sinceLast < 10000) {
      // 새 탭이거나, 되돌린 페이지가 곧바로 다시 차단 사이트로 넘기는 경우(무한 반복 방지)
      recentlyHandled.set(tabId, { url, time: Date.now() });
      await closeTab(tabId);
    } else if (committed) {
      // 이전 페이지가 그대로 돌아오도록 차단 페이지로 넘어간 뒤에 뒤로 간다
      recentlyHandled.set(tabId, { url, time: Date.now() });
      await goBackOrClose(tabId);
    }
  } catch (error) {
    console.error(`[Tab Customizer] 탭 ${tabId}을 처리하지 못했습니다.`, error);
  }
}

// 차단 목록이 바뀌면 지금 열려 있는 차단 사이트 탭을 닫는다.
async function closeOpenBlockedTabs() {
  let state;
  try {
    state = await getBlockState();
  } catch (error) {
    return console.error('[Tab Customizer] 차단 목록을 읽지 못했습니다.', error);
  }
  if (!state.enabled) return;
  // 이제 차단 대상이 된 주소로는 되돌아가지 않도록 기록에서 뺀다
  for (const [tabId, url] of goodUrls) if (isBlocked(state, url)) goodUrls.delete(tabId);
  saveGoodUrls();
  const tabs = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] });
  for (const tab of tabs) {
    if (!isBlocked(state, tab.url)) continue;
    await closeTab(tab.id).catch(error => console.error(`[Tab Customizer] 탭 ${tab.id}을 닫지 못했습니다.`, error));
  }
}

const isTopFrame = details => details.frameId === 0 && details.documentLifecycle !== 'prerender';
chrome.webNavigation.onBeforeNavigate.addListener(details => {
  if (isTopFrame(details)) handleNavigation(details.tabId, details.url, false);
});
chrome.webNavigation.onCommitted.addListener(details => {
  if (!isTopFrame(details)) return;
  handleNavigation(details.tabId, details.url, true);
  handleArrangement(details.tabId, details.url);
  reconnectOmnitoolIfDropped();
});
// 미리 불러 둔 페이지로 바뀌는 경우처럼 위 이벤트 없이 주소가 바뀌는 경우.
// 주소창 입력 직후에도 탭 주소가 먼저 바뀌므로, 실제 화면의 주소와 같을 때만 넘어간 것으로 본다.
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo) => {
  if (!changeInfo.url) return;
  const frame = await chrome.webNavigation.getFrame({ tabId, frameId: 0 }).catch(() => null);
  const committed = frame?.url === changeInfo.url;
  handleNavigation(tabId, changeInfo.url, committed);
  if (committed) handleArrangement(tabId, changeInfo.url);
});
chrome.tabs.onReplaced.addListener((addedTabId, removedTabId) => {
  if (goodUrls.has(removedTabId)) goodUrls.set(addedTabId, goodUrls.get(removedTabId));
  goodUrls.delete(removedTabId);
  saveGoodUrls();
});
chrome.tabs.onRemoved.addListener(tabId => {
  recentlyHandled.delete(tabId);
  if (goodUrls.delete(tabId)) saveGoodUrls();
  if (arrangedDomains.delete(tabId)) saveArrangedDomains();
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (OMNITOOL_SYNC_KEY in changes) changes[OMNITOOL_SYNC_KEY].newValue === true ? connectOmnitool() : disconnectOmnitool();
  if (![BLOCKED_KEY, BLOCK_ENABLED_KEY, OMNITOOL_KEY, OMNITOOL_SYNC_KEY].some(key => key in changes)) return;
  blockState = null;
  closeOpenBlockedTabs();
});

// ── 옴니툴 연결 ──
// Chrome이 켜질 때 옴니툴 연결 프로그램과 연결을 열어 두고, Chrome이 켜져 있는 동안 유지한다.
// 연결 프로그램은 처음 연결될 때와 옴니툴 차단 목록이 바뀔 때마다 목록을 보내온다.
// 연결이 열려 있는 동안은 서비스 워커도 내려가지 않는다.

const OMNITOOL_RECONNECT_MS = 5 * 60 * 1000; // 끊겼을 때 다시 연결을 시도하는 최소 간격
const OMNITOOL_LAST_CONNECT_KEY = 'omnitoolLastConnect';
let omnitoolPort = null;
let omnitoolConnecting = null; // 연결 중인 작업. 여러 곳에서 동시에 불러도 연결은 하나만 연다

async function updateOmnitoolStatus(patch) {
  const previous = (await chrome.storage.local.get(OMNITOOL_STATUS_KEY))[OMNITOOL_STATUS_KEY] || {};
  await chrome.storage.local.set({ [OMNITOOL_STATUS_KEY]: { ...previous, ...patch } });
}

async function receiveOmnitool(message) {
  const now = new Date().toISOString();
  let result;
  try {
    result = parseOmnitoolResponse(message);
  } catch (error) {
    // 받은 내용이 틀리면 마지막으로 받은 목록은 그대로 두고 오류만 기록한다
    return updateOmnitoolStatus({ connected: true, lastAttempt: now, error: error.message });
  }
  await chrome.storage.local.set({
    [OMNITOOL_KEY]: result.blocked,
    [OMNITOOL_STATUS_KEY]: { connected: true, lastAttempt: now, lastSuccess: now, count: Object.keys(result.blocked).length, skipped: result.skipped, error: '' },
  });
}

function connectOmnitool() {
  omnitoolConnecting ??= openOmnitoolPort().finally(() => { omnitoolConnecting = null; });
  return omnitoolConnecting;
}

async function openOmnitoolPort() {
  if (omnitoolPort || !(await loadOmnitoolSync())) return;
  await chrome.storage.session.set({ [OMNITOOL_LAST_CONNECT_KEY]: Date.now() });
  const port = chrome.runtime.connectNative(OMNITOOL_HOST);
  omnitoolPort = port;
  port.onMessage.addListener(message => {
    receiveOmnitool(message).catch(error => console.error('[Tab Customizer] 옴니툴 목록을 저장하지 못했습니다.', error));
  });
  port.onDisconnect.addListener(() => {
    const reason = chrome.runtime.lastError?.message || '연결 프로그램이 끝났습니다.';
    if (omnitoolPort !== port) return; // 직접 끊은 연결
    omnitoolPort = null;
    updateOmnitoolStatus({ connected: false, lastAttempt: new Date().toISOString(), error: describeNativeError(reason) })
      .catch(error => console.error('[Tab Customizer] 옴니툴 상태를 저장하지 못했습니다.', error));
  });
}

async function disconnectOmnitool() {
  const port = omnitoolPort;
  omnitoolPort = null;
  port?.disconnect();
  await updateOmnitoolStatus({ connected: false });
}

// 연결 프로그램이 비정상으로 끝난 경우, 탭을 이동할 때 다시 연결한다(최소 간격을 둔다).
async function reconnectOmnitoolIfDropped() {
  if (omnitoolPort) return;
  const data = await chrome.storage.session.get(OMNITOOL_LAST_CONNECT_KEY);
  if (Date.now() - (data[OMNITOOL_LAST_CONNECT_KEY] || 0) < OMNITOOL_RECONNECT_MS) return;
  connectOmnitool().catch(error => console.error('[Tab Customizer] 옴니툴에 연결하지 못했습니다.', error));
}

// 관리 페이지의 '지금 받아오기': 연결돼 있으면 목록을 다시 요청하고, 아니면 새로 연결한다.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'omnitool-refresh') return;
  if (omnitoolPort) omnitoolPort.postMessage({ type: 'getBlockList', version: 1 });
  else connectOmnitool().catch(error => console.error('[Tab Customizer] 옴니툴에 연결하지 못했습니다.', error));
  sendResponse({ ok: true });
});

const startOmnitool = () => connectOmnitool().catch(error => console.error('[Tab Customizer] 옴니툴에 연결하지 못했습니다.', error));
chrome.runtime.onInstalled.addListener(startOmnitool);
chrome.runtime.onStartup.addListener(startOmnitool);

// ── 탭 정리(그룹·고정) ──
// 규칙 사이트로 들어올 때 한 번만 정리한다. 같은 사이트 안에서 이동할 때는 다시 하지 않으므로
// 사용자가 직접 그룹에서 빼거나 고정을 풀면 그대로 둔다.

const ARRANGED_KEY = 'arrangedDomains';
const arrangedDomains = new Map(); // 탭 id → 그 탭이 마지막으로 들어온 규칙 도메인
const arrangedReady = chrome.storage.session.get(ARRANGED_KEY).then(data => {
  for (const [tabId, domain] of Object.entries(data[ARRANGED_KEY] || {})) arrangedDomains.set(Number(tabId), domain);
});

function saveArrangedDomains() {
  chrome.storage.session.set({ [ARRANGED_KEY]: Object.fromEntries(arrangedDomains) })
    .catch(error => console.error('[Tab Customizer] 탭 정리 기록을 저장하지 못했습니다.', error));
}

// 꾸미기 전체 스위치와 규칙 스위치가 모두 켜진 규칙만 쓴다
async function activeRules() {
  const [rules, enabled] = await Promise.all([loadRules(), loadEnabled()]);
  return enabled ? rules : null;
}

function activeRuleFor(rules, url) {
  if (!rules) return null;
  let hostname;
  try {
    hostname = new URL(url).hostname;
  } catch {
    return null;
  }
  const rule = findRule(rules, hostname);
  return rule?.enabled ? rule : null;
}

async function arrangeTab(tab, rule) {
  if (rule.arrange === 'pin') {
    if (!tab.pinned) await chrome.tabs.update(tab.id, { pinned: true });
    return;
  }
  // 직접 고정한 탭과 팝업 창의 탭은 그룹에 넣을 수 없으므로 그대로 둔다
  if (tab.pinned || (await chrome.windows.get(tab.windowId)).type !== 'normal') return;
  const groups = await chrome.tabGroups.query({ windowId: tab.windowId });
  const group = groups.find(g => g.title === rule.groupName);
  if (group) {
    if (tab.groupId !== group.id) await chrome.tabs.group({ tabIds: tab.id, groupId: group.id });
    if (group.color !== rule.groupColor) await chrome.tabGroups.update(group.id, { color: rule.groupColor });
  } else {
    const groupId = await chrome.tabs.group({ tabIds: tab.id, createProperties: { windowId: tab.windowId } });
    await chrome.tabGroups.update(groupId, { title: rule.groupName, color: rule.groupColor });
  }
}

async function handleArrangement(tabId, url) {
  if (tabId < 0) return;
  await arrangedReady;
  let rule;
  try {
    rule = activeRuleFor(await activeRules(), url);
  } catch (error) {
    return console.error('[Tab Customizer] 규칙을 읽지 못했습니다.', error);
  }
  const previous = arrangedDomains.get(tabId);
  if (!rule) {
    if (previous) {
      arrangedDomains.delete(tabId);
      saveArrangedDomains();
    }
    return;
  }
  if (previous === rule.domain) return;
  arrangedDomains.set(tabId, rule.domain);
  saveArrangedDomains();
  if (!rule.arrange) return;
  const tab = await chrome.tabs.get(tabId).catch(() => null);
  if (tab) await arrangeTab(tab, rule).catch(error => console.error(`[Tab Customizer] 탭 ${tabId}을 정리하지 못했습니다.`, error));
}

// 그룹·고정 설정이 바뀐 규칙은 지금 열려 있는 탭에도 바로 적용한다. changedDomains가 null이면 전부.
async function arrangeOpenTabs(changedDomains) {
  await arrangedReady;
  let rules;
  try {
    rules = await activeRules();
  } catch (error) {
    return console.error('[Tab Customizer] 규칙을 읽지 못했습니다.', error);
  }
  if (!rules) return;
  for (const tab of await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })) {
    const rule = activeRuleFor(rules, tab.url);
    if (!rule?.arrange || (changedDomains && !changedDomains.has(rule.domain))) continue;
    arrangedDomains.set(tab.id, rule.domain);
    await arrangeTab(tab, rule).catch(error => console.error(`[Tab Customizer] 탭 ${tab.id}을 정리하지 못했습니다.`, error));
  }
  saveArrangedDomains();
}

function arrangementKey(raw) {
  const rule = sanitizeRule(raw);
  return rule?.enabled && rule.arrange ? JSON.stringify([rule.arrange, rule.groupName, rule.groupColor]) : '';
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (ENABLED_KEY in changes) return arrangeOpenTabs(null);
  if (!(STORAGE_KEY in changes)) return;
  const before = changes[STORAGE_KEY].oldValue || {};
  const after = changes[STORAGE_KEY].newValue || {};
  if (typeof after !== 'object' || Array.isArray(after)) return;
  const changed = new Set(Object.keys(after).filter(domain => {
    const key = arrangementKey(after[domain]);
    return key && key !== arrangementKey(typeof before === 'object' ? before[domain] : null);
  }));
  if (changed.size) arrangeOpenTabs(changed);
});

// ── 북마크 이름 ──
// 꾸민 탭을 북마크하면 Chrome이 꾸민 이름으로 저장하므로, 페이지의 원래 이름으로 바꿔 둔다.
// 별표 창을 닫을 때 Chrome이 창에 적혀 있던 꾸민 이름을 다시 넣는 경우가 있어, 그 한 번은 다시 되돌린다.
// 사용자가 직접 입력한 이름(꾸민 이름과 다른 이름)은 그대로 둔다. 아이콘은 Chrome이 따로 저장하므로 바꿀 수 없다.

const BOOKMARK_FIX_PREFIX = 'bookmarkFix:'; // + 북마크 id → { applied, original, time }
const BOOKMARK_FIX_MS = 10 * 60 * 1000; // 별표 창이 닫히기를 기다리는 최대 시간

// 그 주소를 연 탭 중 지금 이 이름으로 꾸며진 탭이 있으면 원래 이름을 돌려준다. 없으면 null.
async function originalTitleFor(url, title) {
  for (const tab of await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] })) {
    if (tab.url !== url) continue;
    const titles = await chrome.tabs.sendMessage(tab.id, { type: 'get-titles' }).catch(() => null);
    if (titles?.applied === title) return titles.original;
  }
  return null;
}

chrome.bookmarks.onCreated.addListener(async (id, bookmark) => {
  if (!bookmark.url) return; // 폴더
  try {
    const original = await originalTitleFor(bookmark.url, bookmark.title);
    if (original === null || original === bookmark.title) return;
    await chrome.storage.session.set({ [BOOKMARK_FIX_PREFIX + id]: { applied: bookmark.title, original, time: Date.now() } });
    await chrome.bookmarks.update(id, { title: original });
  } catch (error) {
    console.error('[Tab Customizer] 북마크 이름을 원래 이름으로 바꾸지 못했습니다.', error);
  }
});

chrome.bookmarks.onChanged.addListener(async (id, changeInfo) => {
  const key = BOOKMARK_FIX_PREFIX + id;
  try {
    const fix = (await chrome.storage.session.get(key))[key];
    if (!fix || changeInfo.title === fix.original) return; // 확장이 바꾼 것
    await chrome.storage.session.remove(key);
    if (changeInfo.title === fix.applied && Date.now() - fix.time < BOOKMARK_FIX_MS) await chrome.bookmarks.update(id, { title: fix.original });
  } catch (error) {
    console.error('[Tab Customizer] 북마크 이름을 원래 이름으로 바꾸지 못했습니다.', error);
  }
});

chrome.bookmarks.onRemoved.addListener(id => {
  chrome.storage.session.remove(BOOKMARK_FIX_PREFIX + id)
    .catch(error => console.error('[Tab Customizer] 북마크 기록을 지우지 못했습니다.', error));
});

// 탭 정리(없음·그룹·고정) 입력. 팝업과 관리 페이지가 함께 쓴다.
let arrangeControlCount = 0;

// 다른 규칙에서 쓰는 그룹 이름과 색. 같은 이름을 고르면 색도 맞춰 준다.
function groupsFromRules(rules) {
  const groups = new Map();
  for (const raw of Object.values(rules)) {
    const rule = sanitizeRule(raw);
    if (rule?.arrange === 'group' && !groups.has(rule.groupName)) groups.set(rule.groupName, rule.groupColor);
  }
  return groups;
}

function createArrangeControls(groups) {
  const id = ++arrangeControlCount;
  const root = document.createElement('span');
  root.className = 'arrange';

  const segmented = document.createElement('span');
  segmented.className = 'segmented';
  for (const [value, text] of [['', '없음'], ['group', '그룹'], ['pin', '고정']]) {
    const label = document.createElement('label');
    const radio = Object.assign(document.createElement('input'), { type: 'radio', name: `arrange-${id}`, value });
    label.append(radio, text);
    segmented.appendChild(label);
  }

  const fields = document.createElement('span');
  fields.className = 'input-row group-fields';
  const nameInput = Object.assign(document.createElement('input'), { type: 'text', maxLength: MAX_GROUP_NAME_LENGTH, placeholder: '그룹 이름' });
  nameInput.className = 'group-name';
  const datalist = Object.assign(document.createElement('datalist'), { id: `group-names-${id}` });
  nameInput.setAttribute('list', datalist.id);
  for (const name of groups.keys()) datalist.appendChild(Object.assign(document.createElement('option'), { value: name }));
  const colorSelect = document.createElement('select');
  colorSelect.className = 'group-color';
  colorSelect.title = '그룹 색';
  for (const [color, text] of GROUP_COLORS) {
    colorSelect.appendChild(Object.assign(document.createElement('option'), { value: color, textContent: text }));
  }
  fields.append(nameInput, datalist, colorSelect);
  root.append(segmented, fields);

  const selected = () => segmented.querySelector('input:checked')?.value || '';
  const update = () => { fields.hidden = selected() !== 'group'; };
  segmented.addEventListener('change', () => {
    update();
    if (selected() === 'group') nameInput.focus();
  });
  nameInput.addEventListener('input', () => {
    const color = groups.get(nameInput.value.trim());
    if (color) colorSelect.value = color;
  });

  return {
    element: root,
    set(rule) {
      const arrange = rule?.arrange || '';
      segmented.querySelector(`input[value="${arrange}"]`).checked = true;
      nameInput.value = rule?.groupName || '';
      colorSelect.value = rule?.groupColor || 'grey';
      update();
    },
    // 규칙에 그대로 넣을 값. 그룹인데 이름이 없으면 null.
    get() {
      const arrange = selected();
      if (arrange === 'pin') return { arrange };
      if (arrange !== 'group') return {};
      const groupName = nameInput.value.trim();
      return groupName ? { arrange, groupName, groupColor: colorSelect.value } : null;
    },
  };
}

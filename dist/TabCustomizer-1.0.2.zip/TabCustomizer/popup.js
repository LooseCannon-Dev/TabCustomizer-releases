const form = document.getElementById('form');
const domainInput = document.getElementById('domain');
const titleInput = document.getElementById('title');
const preview = document.getElementById('preview');
const iconNone = document.getElementById('icon-none');
const removeButton = document.getElementById('remove');
const siteToggleRow = document.getElementById('site-toggle-row');
const siteToggle = document.getElementById('site-toggle');
const globalToggle = document.getElementById('global-toggle');
const blockToggle = document.getElementById('block-toggle');
const blockButton = document.getElementById('block-site');
const message = document.getElementById('message');

let savedDomain = null; // 현재 탭에 적용 중인 규칙의 도메인
let selectedIcon = { emoji: '' }; // { emoji } 또는 { emoji: '', iconId }. 둘 다 비면 원래 아이콘 유지
let icons = {}; // 올린 그림
let arrangeControls = null;

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.toggle('error', isError);
}

// 지워진 그림을 가리키면 원래 아이콘으로 본다
function setIcon(choice) {
  selectedIcon = choice.iconId && !icons[choice.iconId] ? { emoji: '' } : choice;
  const url = iconUrlFor(selectedIcon, icons);
  preview.hidden = !url;
  iconNone.hidden = !!url;
  if (url) preview.src = url;
}

function showSavedState(rule) {
  removeButton.hidden = !savedDomain;
  siteToggleRow.hidden = !savedDomain;
  siteToggle.checked = rule ? rule.enabled : true;
}

async function initSwitches() {
  globalToggle.checked = await loadEnabled();
  document.getElementById('global-off').hidden = globalToggle.checked;
  blockToggle.checked = await loadBlockEnabled();
}

async function init() {
  document.getElementById('reload-needed').hidden = !needsReload();
  initSwitches();
  try {
    icons = await loadIcons();
  } catch (error) {
    showMessage('올린 그림을 읽지 못했습니다: ' + error.message, true);
  }
  document.getElementById('picker').appendChild(createEmojiPicker(setIcon, icons, "관리 페이지의 '내 아이콘'에서 그림을 올리면 여기서 고를 수 있습니다."));

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  let url = null;
  try {
    url = new URL(tab?.url);
  } catch {
    // 주소를 알 수 없는 탭은 지원하지 않는 페이지로 처리한다
  }
  if (!url || !['http:', 'https:'].includes(url.protocol)) {
    document.getElementById('unsupported').hidden = false;
    return;
  }

  form.hidden = false;
  blockButton.hidden = false;
  blockButton.dataset.domain = url.hostname.replace(/^www\./, '');
  setIcon({ emoji: '' });
  try {
    const rules = await loadRules();
    arrangeControls = createArrangeControls(groupsFromRules(rules));
    document.getElementById('arrange').appendChild(arrangeControls.element);
    const rule = findRule(rules, url.hostname);
    arrangeControls.set(rule);
    if (rule) {
      savedDomain = rule.domain;
      domainInput.value = rule.domain;
      titleInput.value = rule.title;
      setIcon(iconChoice(rule));
    } else {
      domainInput.value = url.hostname.replace(/^www\./, '');
    }
    showSavedState(rule);
  } catch (error) {
    showMessage(error.message, true);
    form.querySelector('button[type="submit"]').disabled = true;
  }
}

form.addEventListener('submit', async event => {
  event.preventDefault();
  const domain = normalizeDomain(domainInput.value);
  const title = titleInput.value.trim();

  const arrangement = arrangeControls.get();
  if (!domain) return showMessage('사이트 주소 형식이 올바르지 않습니다.', true);
  if (!arrangement) return showMessage('그룹 이름을 입력해 주세요.', true);
  if (!title && !selectedIcon.emoji && !selectedIcon.iconId && !arrangement.arrange) return showMessage('탭 이름, 아이콘, 탭 정리 중 하나는 정해 주세요.', true);

  let enabled = true;
  try {
    const existing = await loadRules();
    if (domain !== savedDomain && existing[domain] && !confirm(`${domain}에 이미 규칙이 있습니다. 덮어쓸까요?`)) return;
    await updateRules(rules => {
      // 도메인을 고쳐 저장하면 이전 도메인 규칙은 새 도메인으로 옮긴다. 켜짐/꺼짐 상태는 유지한다.
      if (savedDomain && rules[savedDomain]) enabled = rules[savedDomain].enabled !== false;
      if (savedDomain && savedDomain !== domain) delete rules[savedDomain];
      rules[domain] = { title, ...selectedIcon, enabled, ...arrangement };
    });
  } catch (error) {
    return showMessage('저장하지 못했습니다: ' + error.message, true);
  }
  savedDomain = domain;
  domainInput.value = domain;
  showSavedState({ enabled });
  showMessage(enabled ? '저장했습니다.' : '저장했습니다. 이 사이트는 꺼져 있어 아직 적용되지 않습니다.');
});

removeButton.addEventListener('click', async () => {
  if (!savedDomain || !confirm(`${savedDomain} 규칙을 삭제할까요?`)) return;
  try {
    await updateRules(rules => { delete rules[savedDomain]; });
  } catch (error) {
    return showMessage('삭제하지 못했습니다: ' + error.message, true);
  }
  savedDomain = null;
  showSavedState(null);
  showMessage('삭제했습니다. 탭이 원래대로 돌아갑니다.');
});

siteToggle.addEventListener('change', async () => {
  const enabled = siteToggle.checked;
  try {
    await updateRules(rules => {
      if (!rules[savedDomain]) throw new Error('규칙이 삭제되어 있습니다.');
      rules[savedDomain].enabled = enabled;
    });
  } catch (error) {
    siteToggle.checked = !enabled;
    return showMessage('바꾸지 못했습니다: ' + error.message, true);
  }
  showMessage(enabled ? '이 사이트에 다시 적용합니다.' : '이 사이트는 원래대로 보입니다. 규칙은 남아 있습니다.');
});

globalToggle.addEventListener('change', async () => {
  const enabled = globalToggle.checked;
  try {
    await chrome.storage.local.set({ [ENABLED_KEY]: enabled });
  } catch (error) {
    globalToggle.checked = !enabled;
    return showMessage('바꾸지 못했습니다: ' + error.message, true);
  }
  document.getElementById('global-off').hidden = enabled;
});

blockToggle.addEventListener('change', async () => {
  const enabled = blockToggle.checked;
  try {
    await chrome.storage.local.set({ [BLOCK_ENABLED_KEY]: enabled });
  } catch (error) {
    blockToggle.checked = !enabled;
    return showMessage('바꾸지 못했습니다: ' + error.message, true);
  }
  showMessage(enabled ? '차단을 켰습니다. 열려 있는 차단 사이트 탭은 닫힙니다.' : '차단을 껐습니다. 차단 목록은 남아 있습니다.');
});

blockButton.addEventListener('click', async () => {
  const domain = blockButton.dataset.domain;
  try {
    const count = await countOpenTabs(domain);
    const notice = blockToggle.checked
      ? `지금 열려 있는 이 사이트 탭 ${count}개(이 탭 포함)가 닫힙니다.`
      : '차단 기능이 꺼져 있어 켜기 전까지는 닫히지 않습니다.';
    if (!confirm(`${domain}을(를) 차단할까요? 하위 주소도 함께 차단됩니다.\n${notice}`)) return;
    await updateBlocked(blocked => { blocked[domain] = { enabled: true }; });
  } catch (error) {
    return showMessage('차단하지 못했습니다: ' + error.message, true);
  }
  showMessage(`${domain}을(를) 차단 목록에 추가했습니다.`);
});

document.getElementById('auto-title').addEventListener('click', () => {
  const domain = normalizeDomain(domainInput.value);
  if (!domain) return showMessage('사이트 주소를 먼저 바르게 입력해 주세요.', true);
  titleInput.value = nameFromDomain(domain);
  showMessage('');
});

document.getElementById('auto-emoji').addEventListener('click', async () => {
  try {
    setIcon({ emoji: autoEmoji(await loadRules(), savedDomain) });
    showMessage('');
  } catch (error) {
    showMessage(error.message, true);
  }
});

document.getElementById('clear-emoji').addEventListener('click', () => setIcon({ emoji: '' }));
document.getElementById('open-options').addEventListener('click', event => {
  event.preventDefault();
  chrome.runtime.openOptionsPage();
});

init();

// 분류별 이모지 선택 목록과 '내 아이콘'(올린 그림). 고르면 onSelect({ emoji }) 또는 onSelect({ emoji: '', iconId })를 부른다.
function createEmojiPicker(onSelect, icons, noIconsText) {
  const root = document.createElement('div');
  root.className = 'picker';
  const tabs = document.createElement('div');
  tabs.className = 'picker-tabs';
  const grid = document.createElement('div');
  grid.className = 'picker-grid';
  const categories = [...EMOJI_CATEGORIES, { name: '내 아이콘', icons: sortedIcons(icons) }];

  function option(title, onClick) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'emoji-option';
    button.title = title;
    button.addEventListener('click', onClick);
    return button;
  }

  function show(index) {
    [...tabs.children].forEach((tab, i) => tab.classList.toggle('active', i === index));
    const category = categories[index];
    if (category.icons && !category.icons.length) {
      return grid.replaceChildren(Object.assign(document.createElement('p'), { className: 'picker-empty', textContent: noIconsText }));
    }
    grid.replaceChildren(...(category.icons || category.emojis).map(item => {
      if (typeof item === 'string') {
        const button = option(item, () => onSelect({ emoji: item }));
        button.textContent = item;
        return button;
      }
      const button = option(item.name, () => onSelect({ emoji: '', iconId: item.id }));
      button.appendChild(Object.assign(document.createElement('img'), { className: 'icon-preview', src: item.data, alt: '' }));
      return button;
    }));
  }

  categories.forEach((category, index) => {
    const tab = document.createElement('button');
    tab.type = 'button';
    tab.textContent = category.name;
    tab.addEventListener('click', () => show(index));
    tabs.appendChild(tab);
  });
  show(0);
  root.append(tabs, grid);
  return root;
}
